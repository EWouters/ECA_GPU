#ifndef P2P_H
#define P2P_H

#include <stdlib.h>
#include <stdint.h>
#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <time.h>

void p2p(int np, int32_t *x, float *pp, int mindist);

#endif
