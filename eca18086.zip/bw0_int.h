#ifndef BW0_INT_H_
#define BW0_INT_H_

#include <stdint.h>

#define order 10
extern void bw0_int(int np, int32_t *x, int32_t *y);

#endif /* BW0_INT_H_ */
